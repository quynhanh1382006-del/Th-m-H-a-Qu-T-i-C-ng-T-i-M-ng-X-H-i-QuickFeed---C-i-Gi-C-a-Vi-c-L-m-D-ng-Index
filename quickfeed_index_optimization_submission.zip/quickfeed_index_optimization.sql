-- QuickFeed: Index optimization
-- Run in MySQL after confirming the schema and existing indexes.

CREATE DATABASE IF NOT EXISTS quickfeed_db;
USE quickfeed_db;

-- Create the example table if it does not already exist.
-- If Posts already exists, this statement leaves the existing table unchanged.
CREATE TABLE IF NOT EXISTS Posts (
    post_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    content TEXT,
    post_type VARCHAR(10),
    is_visible BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_content (content(255)),
    INDEX idx_post_type (post_type),
    INDEX idx_is_visible (is_visible),
    INDEX idx_created_at (created_at)
);

-- Record storage statistics BEFORE dropping indexes.
SELECT
    TABLE_SCHEMA,
    TABLE_NAME,
    ROUND(DATA_LENGTH / 1024 / 1024, 3) AS data_mb,
    ROUND(INDEX_LENGTH / 1024 / 1024, 3) AS index_mb,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 3) AS total_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'quickfeed_db'
  AND TABLE_NAME = 'Posts';

SHOW TABLE STATUS LIKE 'Posts';

-- Drop only the three indexes identified as candidates for removal.
-- If an index does not exist, MySQL may report an error; check SHOW INDEX first.
-- MySQL 8.0+ supports DROP INDEX IF EXISTS in some distributions, but not all.
ALTER TABLE Posts DROP INDEX idx_content;
ALTER TABLE Posts DROP INDEX idx_post_type;
ALTER TABLE Posts DROP INDEX idx_is_visible;

-- Confirm remaining indexes.
SHOW INDEX FROM Posts;

-- Record storage statistics AFTER dropping indexes.
SELECT
    TABLE_SCHEMA,
    TABLE_NAME,
    ROUND(DATA_LENGTH / 1024 / 1024, 3) AS data_mb,
    ROUND(INDEX_LENGTH / 1024 / 1024, 3) AS index_mb,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 3) AS total_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'quickfeed_db'
  AND TABLE_NAME = 'Posts';

SHOW TABLE STATUS LIKE 'Posts';

-- Notes:
-- 1) Capture the BEFORE and AFTER outputs and add the actual figures to the report.
-- 2) The table may show little/no reduction if it contains very few rows.
-- 3) Dropping indexes reduces maintenance work on INSERT/UPDATE/DELETE but can
--    make queries that depended on those indexes slower.
