# QuickFeed — Báo cáo tối ưu Index

## Mục tiêu
Giảm chi phí lưu trữ và ghi dữ liệu bằng cách loại bỏ ba Index không phù hợp, đồng thời giữ các Index phục vụ truy vấn thường gặp.

## Quyết định
Giữ `idx_user_id` để hỗ trợ truy vấn bài viết theo người dùng và `idx_created_at` để hỗ trợ lọc/sắp xếp theo thời gian. Loại bỏ `idx_content`, `idx_post_type` và `idx_is_visible`. Index tiền tố trên `TEXT` có thể chiếm thêm dung lượng và không thay thế cơ chế tìm kiếm toàn văn. `post_type` chỉ có vài giá trị, còn `is_visible` chỉ có hai giá trị; nếu truy vấn trả về phần lớn bảng, MySQL có thể chọn quét bảng thay vì đọc Index rồi truy xuất nhiều hàng.

## Read/Write trade-off
Index phù hợp có thể tăng tốc `SELECT`, nhưng mỗi `INSERT`, `UPDATE` hoặc `DELETE` phải duy trì các cấu trúc Index liên quan. Mỗi Index bổ sung tạo thêm thao tác ghi trang Index, sử dụng bộ nhớ đệm và chiếm dung lượng đĩa. Xóa ba Index giúp giảm chi phí bảo trì và có thể cải thiện tốc độ ghi; đổi lại, các truy vấn lọc theo `content`, `post_type` hoặc `is_visible` có thể chậm hơn. Nếu cần tìm từ khóa trong `content`, hãy đánh giá `FULLTEXT INDEX` dựa trên truy vấn thực tế.

## Đối chiếu dung lượng
Chạy truy vấn `information_schema.TABLES` trước và sau khi xóa Index, rồi ghi số liệu thật:

| Chỉ số | Trước tối ưu | Sau tối ưu |
|---|---:|---:|
| Data size (MB) | Điền số đo thực tế | Điền số đo thực tế |
| Index size (MB) | Điền số đo thực tế | Điền số đo thực tế |
| Tổng (MB) | Điền số đo thực tế | Điền số đo thực tế |

Không điền số liệu ước đoán. Trên bảng thử nghiệm ít dữ liệu, chênh lệch có thể nhỏ hoặc khó quan sát ngay; dung lượng được báo cáo cũng phụ thuộc phiên bản MySQL và engine.

## Kết luận
Đã chọn loại bỏ ba Index dư thừa theo yêu cầu và giữ lại hai Index có mục đích sử dụng rõ ràng. Cần đính kèm kết quả đo trước/sau từ môi trường chạy thực tế để xác nhận mức tiết kiệm dung lượng.
