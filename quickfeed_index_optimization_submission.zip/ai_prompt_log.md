# AI Prompt Log — QuickFeed Index Optimization

## Prompt 1: Cardinality
**Câu hỏi:** Cardinality của Index là gì? Vì sao cột BOOLEAN hoặc cột chỉ có vài giá trị thường không phù hợp với B-Tree Index?

**Tóm tắt:** Cardinality là số lượng giá trị phân biệt trong cột (ước lượng đối với thống kê Index). Cột có ít giá trị phân biệt có độ chọn lọc thấp. Nếu điều kiện truy vấn khớp với phần lớn hàng, việc đi qua Index rồi đọc nhiều hàng từ bảng có thể tốn hơn quét bảng. Index trên cột ít giá trị không phải lúc nào cũng vô dụng; hiệu quả còn phụ thuộc phân bố dữ liệu, truy vấn, Index ghép và kế hoạch thực thi.

## Prompt 2: Storage overhead
**Câu hỏi:** Index làm tăng dung lượng và chi phí INSERT như thế nào trong InnoDB?

**Tóm tắt:** InnoDB lưu dữ liệu bảng trong cấu trúc clustered index (thường theo khóa chính) và lưu các secondary index riêng. Khi thêm hàng, MySQL cần cập nhật clustered index và các secondary index; các thao tác có thể gây ghi trang, chia trang, ghi log và sử dụng buffer pool. Nhiều Index làm tăng dung lượng đĩa và công việc duy trì khi INSERT/UPDATE/DELETE.

## Prompt 3: TEXT search
**Câu hỏi:** Nên tìm từ khóa trong cột TEXT bằng cách nào?

**Tóm tắt:** B-Tree Index tiền tố không cung cấp tìm kiếm toàn văn tổng quát. Với tìm kiếm từ/ngôn ngữ tự nhiên, cân nhắc FULLTEXT INDEX và cú pháp MATCH(...) AGAINST(...). Cần kiểm tra yêu cầu ngôn ngữ, tokenization, kiểu tìm kiếm và kế hoạch truy vấn.

## Prompt 4: Đo trước/sau
**Câu hỏi:** Làm sao xem dung lượng dữ liệu và Index của bảng trong MySQL?

**Tóm tắt:** Truy vấn information_schema.TABLES, lấy DATA_LENGTH và INDEX_LENGTH, chia cho 1024^2 để hiển thị MB. Ghi số liệu trước và sau khi xóa Index trên cùng bảng và môi trường. SHOW TABLE STATUS cũng cung cấp thông tin gần tương tự.

## Ghi chú thực hành
Nội dung trên là tóm tắt kiến thức hỗ trợ làm bài. Hãy bổ sung ngày chạy, phiên bản MySQL, câu lệnh đã thực thi và kết quả đo thực tế của chính bạn trước khi nộp.
